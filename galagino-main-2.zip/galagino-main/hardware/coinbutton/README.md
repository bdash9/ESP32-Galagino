# Coin Button

This is a simple bracket needed to mount the coin button to the
[cabinet](../cabinet).

![CAD](coinbutton.png)

Additionally needed:

- Two screws M2 x 8mm
- One 6x6mm push button, through hole, height 9mm

The coinbutton is screwed to part 6 of the [cabinet](../cabinet).

![Photo](coinbutton.jpg)